**_Unity High Level Multiplayer API_**

See the manual section in the [Unity website manual](https://docs.unity3d.com/Manual/UNetUsingHLAPI.html).

## Document revision history
 
|Date|Reason|
|---|---|
|Nov 13, 2018|Document created. Matches package version 0.2.1-preview.|
