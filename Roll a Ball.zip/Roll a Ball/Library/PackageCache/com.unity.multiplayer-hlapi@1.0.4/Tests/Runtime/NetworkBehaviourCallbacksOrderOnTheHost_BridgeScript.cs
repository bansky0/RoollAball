﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkBehaviourCallbacksOrderOnTheHost_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "NetworkBehaviourCallbacksOrderOnTheHost_BridgeScript_BridgeScriptGO";

    public GameObject playerPrefab;
}
